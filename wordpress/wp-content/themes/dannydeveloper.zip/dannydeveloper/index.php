<?php
get_header();
?>
<div class="wrapper">
    <?php get_template_part('loop','index');?>   
</div>
<!--End Wrapper-->

<?php
get_footer();
?>