<h3 class="widget-title">Search</h3>        
<div class="searchbar">
        <form action="/" method="get">
        <input type="text" name="search" palceholder="Type your search...">
        <button type="submit"><i class="fas fa-search"></i></button>
    </form>
</div>